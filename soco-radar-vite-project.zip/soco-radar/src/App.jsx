import { useState, useRef } from "react";
import SocialCompactRadar from "./RadarApp.jsx";

const GOLD = "#C9A24B";
const INK = "#1E1B16";
const PAPER = "#FAF7F0";

function getApiKey() {
  return localStorage.getItem("soco-api-key") || "";
}

export default function App() {
  const [key, setKeyState] = useState(getApiKey());
  const [draft, setDraft] = useState("");
  const importRef = useRef(null);

  const saveKey = () => {
    const k = draft.trim();
    if (!k.startsWith("sk-ant-")) {
      alert("That doesn't look like an Anthropic API key (they start with sk-ant-).");
      return;
    }
    localStorage.setItem("soco-api-key", k);
    setKeyState(k);
  };

  const changeKey = () => {
    localStorage.removeItem("soco-api-key");
    setKeyState("");
    setDraft("");
  };

  const backup = () => {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("soco:")) data[k] = localStorage.getItem(k);
    }
    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "soco-radar-backup-" + new Date().toISOString().slice(0, 10) + ".json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const doImport = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const data = JSON.parse(r.result);
        if (!confirm("Importing replaces this browser's boards with the file's data. Continue?")) return;
        Object.keys(data).forEach((k) => {
          if (k.startsWith("soco:")) localStorage.setItem(k, data[k]);
        });
        location.reload();
      } catch (err) {
        alert("That file couldn't be read as a radar backup.");
      }
    };
    r.readAsText(file);
    e.target.value = "";
  };

  if (!key) {
    return (
      <div style={S.gateWrap}>
        <div style={S.gateFrame}>
          <div style={S.gateInner}>
            <div style={S.gateWord}>SOCIAL COMPACT</div>
            <div style={S.gateTag}>SoCo Intelligence Radar</div>
            <p style={S.gateP}>
              One-time setup: paste your Anthropic API key to power the live web
              scans. Create one at console.anthropic.com &rarr; API keys.
            </p>
            <input
              style={S.gateInput}
              type="password"
              placeholder="sk-ant-…"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && saveKey()}
            />
            <button style={S.gateBtn} onClick={saveKey}>
              Start the radar
            </button>
            <p style={S.gateSmall}>
              The key is stored only in this browser and sent only to
              api.anthropic.com. Scans cost a few cents each. Don't set this up
              on a shared or public computer. For a team deployment where the
              key stays hidden on a server, see the README (server proxy).
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div style={S.bar}>
        <span>Data lives in this browser.</span>
        <button style={S.btn} onClick={backup}>
          Backup boards (JSON)
        </button>
        <button style={S.btn} onClick={() => importRef.current && importRef.current.click()}>
          Import
        </button>
        <input
          ref={importRef}
          type="file"
          accept="application/json"
          style={{ display: "none" }}
          onChange={doImport}
        />
        <button style={S.btn} onClick={changeKey}>
          Change API key
        </button>
      </div>
      <SocialCompactRadar />
    </div>
  );
}

const S = {
  bar: {
    fontFamily: "'Inter', sans-serif",
    maxWidth: 980,
    margin: "0 auto",
    padding: "10px 20px 0",
    display: "flex",
    gap: 10,
    alignItems: "center",
    flexWrap: "wrap",
    fontSize: 12,
    color: "#8A8578",
  },
  btn: {
    background: "none",
    border: "1px solid #C9C3B4",
    color: "#55503F",
    fontSize: 12,
    fontWeight: 600,
    padding: "5px 12px",
    cursor: "pointer",
    borderRadius: 999,
    fontFamily: "'Inter', sans-serif",
  },
  gateWrap: {
    fontFamily: "'Inter', sans-serif",
    minHeight: "100vh",
    background: PAPER,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  gateFrame: {
    background: "#FFFDF8",
    borderRadius: 18,
    borderTop: `4px solid ${GOLD}`,
    border: "1px solid #EAE3D2",
    boxShadow: "0 8px 30px rgba(30,27,22,.10)",
    maxWidth: 520,
    overflow: "hidden",
  },
  gateInner: { padding: "30px 32px" },
  gateWord: { fontWeight: 700, fontSize: 18, letterSpacing: "0.16em", color: INK },
  gateTag: {
    fontSize: 11.5,
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    color: "#9A7B0A",
    fontWeight: 600,
    marginTop: 3,
  },
  gateP: { fontSize: 13.5, lineHeight: 1.65, color: "#55503F" },
  gateInput: {
    width: "100%",
    padding: "11px 13px",
    fontSize: 14,
    boxSizing: "border-box",
    border: `1px solid ${GOLD}`,
    background: "#FFFDF8",
    borderRadius: 10,
    fontFamily: "'Inter', sans-serif",
  },
  gateBtn: {
    marginTop: 12,
    background: INK,
    color: PAPER,
    border: "none",
    padding: "11px 22px",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
    borderRadius: 999,
    fontFamily: "'Inter', sans-serif",
  },
  gateSmall: { fontSize: 11.5, lineHeight: 1.6, color: "#8A8578", marginTop: 14 },
};
