import React from "react";
import ReactDOM from "react-dom/client";
import "./lib/storage.js"; // installs window.storage (must run before App)
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
