# SoCo Intelligence Radar

An internal tool for **Social Compact** with two parts, switchable from the top bar:

- **Intelligence Radar** — weekly scans of the whole web for **RFPs & Requirements**, **Posts & Opinions** (what corporate leaders are saying about workers), and **Events & Workshops** in the social-sustainability / labour / worker-wellbeing space. Region-selectable (India, global, or any country), with verified source links, statuses, team notes, an AI weekly digest, a shareable PDF report, and CSV export.
- **People Finder** — find named professionals in the same space. Pick target companies and a country, then scan. Results carry verified profile links, statuses, notes, and an AI-drafted intro note.

Built with React + Vite. AI scans use the Anthropic API (Claude with web search) directly from the browser.

---

## Quick start

You need [Node.js](https://nodejs.org) 18+ installed.

```bash
npm install
npm run dev
```

This opens the app at http://localhost:5173. On first load it asks for an
**Anthropic API key** (create one at https://console.anthropic.com → API keys).
The key is stored only in your browser's localStorage and is sent only to
`api.anthropic.com`. Each scan costs a few cents.

## Build for production

```bash
npm run build      # outputs static files to dist/
npm run preview    # serve the built app locally to check it
```

The `dist/` folder is plain static files — host it anywhere: Netlify, Vercel,
GitHub Pages, S3, or your own intranet.

---

## Where does the data live?

By default, each board is stored in the **browser's localStorage** on the
device using it. That means:

- No server or database is required — it just works.
- Boards are per-browser. Use the **Backup boards (JSON)** button in the top
  toolbar to export, and **Import** on another machine to load it.

### Want one shared board for the whole team?

Replace the body of `src/lib/storage.js` with calls to a hosted key-value
store (e.g. [Supabase](https://supabase.com) — free tier is plenty). The rest
of the app already uses that interface, so nothing else needs to change. Ask
your developer, or come back and this can be wired up.

---

## Security note & optional server proxy

For convenience, the app calls the Anthropic API **directly from the browser**
using the key you paste in. This is fine for individual internal use, but the
key is visible to anyone using that browser profile. **Do not deploy this
publicly with a shared key.**

For a proper team deployment, put a tiny **server-side proxy** in front of the
API so the key lives on the server and never reaches the browser:

1. Create a serverless function (Vercel/Netlify function, or a small Express
   route) that receives the request body, adds the `x-api-key` header from a
   server-side environment variable, and forwards it to
   `https://api.anthropic.com/v1/messages`.
2. In `src/RadarApp.jsx`, change the two `fetch("https://api.anthropic.com/...")`
   calls to point at your proxy path (e.g. `/api/anthropic`) and remove the
   `x-api-key` / `anthropic-dangerous-direct-browser-access` headers.

That keeps the key secret and lets the whole team share one deployment.

---

## Project structure

```
soco-radar/
├── index.html            # Vite entry
├── vite.config.js
├── package.json
├── README.md
└── src/
    ├── main.jsx          # mounts the app; installs the storage shim first
    ├── App.jsx           # API-key gate + Backup/Import toolbar
    ├── RadarApp.jsx       # the whole tool: Intelligence Radar + People Finder
    └── lib/
        └── storage.js    # localStorage-backed window.storage (swap for a DB to share)
```

## Notes

- LinkedIn and X can't be read wholesale — the scans surface only publicly
  indexed content, so most results are tagged **Web**. That's expected.
- People Finder uses **public professional information only**. Verify every
  result and reach out respectfully.
- Always click through and verify a source before acting on it; AI research is
  a fast starting point, not a substitute for checking.
